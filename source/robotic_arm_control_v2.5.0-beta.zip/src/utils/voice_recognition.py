import speech_recognition as sr
import google.generativeai as genai
import pyaudio
import numpy as np
import struct
import time
import wave
import tempfile
import os

# Configurações de áudio
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
CHUNK = 2048
THRESHOLD = 350000
RECORD_SECONDS = 2

state = None

def get_api_key_from_setup_file() -> str:
    '''
        Esta função extrai a chave api diretamente do arquivo de configurações, garantindo que qualquer mudança
        seja refletida aqui instantâneamente.
    '''
    
    # Caminho do arquivo
    setup_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "setup.txt"))

    if os.path.exists(setup_path):

        with open(setup_path, 'r') as setup_file:
            for line in setup_file:
                if line.startswith('api_key='):
                    return line.strip().split('=')[1]
                
    return ""

def voice_activity_detection():
    '''
        Esta função detecta variação de volume de acordo com um limite já estabelecido.
        Caso o limite tenha sido ultrapassado, é iniciada a grvação de uma amostra de áudio.
    '''

    p = pyaudio.PyAudio()
    stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
    global state
    state = "Listening..."
    print(state)
    recording = False
    audio_data = []
    start_time = None

    while True:

        # Leitura do arquivo de flag para garantir que o loop pare imediatamente quando necessário
        with open("flag.txt", "r") as f:
            status = f.read().strip()
        if status == "0":
            break
        
        # Aquisição de dados para comparação
        data = stream.read(CHUNK, exception_on_overflow=False)
        fmt = f"{CHUNK}h"
        data_int = np.array(struct.unpack(fmt, data))
        energy = abs((np.sum(data_int ** 2) / len(data_int)))

        # Comparação
        if energy > THRESHOLD:
            state = "Voice detected"
            print(state)
            if not recording:
                start_time = time.time()
            recording = True

        # Criação de um arquivo temporário de áudio
        if recording:
            audio_data.append(data)

        if recording and time.time() - start_time > RECORD_SECONDS:
            
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
                wf = wave.open(temp_audio.name, 'wb')
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(p.get_sample_size(FORMAT))
                wf.setframerate(RATE)
                wf.writeframes(b''.join(audio_data))
                wf.close()
                yield temp_audio.name
            
            recording = False
            audio_data = []

    # Nunca acessado, a não ser que ocorra uma falha no loop. Caso ocorra, para a stream corretamente.
    stream.stop_stream()
    stream.close()
    p.terminate()

def transcribe_audio() -> str:
    '''
        Esta função transcreve uma amostra de áudio para texto. Retorna uma string com o texto transcrito no idioma inglês.
    '''

    global state
    recognizer = sr.Recognizer()
    
    for audio_file in voice_activity_detection():

        with sr.AudioFile(audio_file) as source:

            try:

                # Carrega a amostra de áudio do arquivo temporário gerado na função voice_activity_detection
                audio = recognizer.record(source)
                state = "Processing..."
                print(state)
                
                # Transcrevição áudio para texto
                text = recognizer.recognize_google(audio, language="en-US")
                state = f"You said: {text}"
                print(state)

                return text

            except sr.WaitTimeoutError:
                return "none"
            except sr.UnknownValueError:
                return "none"
            except sr.RequestError:
                return "none"

def summarize_audio() -> str:
    '''
        Esta função resume um texto (string) de acordo com uma instrução já estabelecida.
        Utiliza o modelo gemini-2.0-flash. Retorna uma string com o texto resumido.
    '''

    key = get_api_key_from_setup_file()
    genai.configure(api_key=str(key))
    mic_audio = transcribe_audio()

    # Configuração do modelo
    generation_config = {
        "temperature": 1,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
        "response_mime_type": "text/plain",
    }

    # Criação do modelo
    model = genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        generation_config=generation_config,
    )

    chat_session = model.start_chat(history=[])

    # Instrução para a classificação de áudio
    INPUT = f"Take the sentence I am about to write and select which of the following 6 classes it summarizes. Classes (up, down, left, right, open, close, none). Respond with only the chosen class in lowercase letters. Sentence: {mic_audio}"

    try:
        response = chat_session.send_message(INPUT)
    except:
        return "alternative_stop_flag"

    print(f"Detected class: {response.text}")
    return response.text
