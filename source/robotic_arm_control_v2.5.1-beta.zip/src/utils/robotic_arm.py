import numpy as np
from typing import Tuple, Any
from numpy import ndarray, dtype, floating
from numpy._typing import _64Bit

def calculate_rotating_base_angle(m_coord_x: float) -> int:
    '''
        Esta função calcula o ângulo da base rotatória do braço robótico de acodo com a coordenada no eixo x da mão identificada
        em pixles, mapeando esse ângulo de acordo com largura da área de atuação dos gestos.
        Retorna um inteiro com o ângulo calculado.
    '''
    rotating_base_angle = map(m_coord_x, 110, 530, 0, 180)
    return int(rotating_base_angle)

def calculate_angle_hastes(m_coord_y: float) -> Tuple[int, int]:
    '''
        Esta função calcula os ângulos das hastes do braço robótico de acordo com a coordenada no eixo y da mão identificada em pixels,
        mapeando esses ângulos de acordo com a altura da área de atuação dos gestos.
        Retorna dois inteiros com os respectivos ângulos.
    '''
    arm2_angle = map(m_coord_y, 80, 400, 95, 180)
    aux_h1 = (180 * 95) // arm2_angle
    return int(aux_h1), int(arm2_angle)

def calculate_gripper_angle(garra_state: bool) -> Tuple[int, str]:
    '''
        Esta função escolhe o ângulo da garra do braço robótico de acordo com o estado. Retorna uma tuple com um inteiro (ângulo) e uma string (estado).
    '''
    if garra_state == 0:
        return 10, "Closed"
    elif garra_state == 1:
        return 120, "Open"

def is_moving_axis_x(pixel_threshold: int, prev_m_coord_x: float, m_coord_x: float) -> bool:
    '''
        Esta função verifica se a mão está se movendo no eixo x de acordo com a sua coordenada atual, a coordenada anterior
        e um limite estabelecido, todos em pixels. Retorna um booleano com o resultado.
    '''
    if abs(prev_m_coord_x - m_coord_x) > pixel_threshold:
        return True
    return False

def is_moving_axis_y(pixel_threshold: int, prev_m_coord_y: float, m_coord_y: float) -> bool:
    '''
        Esta função verifica se a mão está se movendo no eixo y de acordo com a sua coordenada atual, a coordenada anterior
        e um limite estabelecido, todos em pixels. Retorna um booleano com o resultado.
    '''
    if abs(prev_m_coord_y - m_coord_y) > pixel_threshold:
        return True
    return False

def map(value: float, min_val: float, max_val: float, min_target: float, max_target: float) -> ndarray[Any, dtype[floating[_64Bit] | np.float64]]:
    '''
        Essa função realiza uma interpolação linear. Ela converte um valor de um intervalo original (min_val a max_val)
        para um valor correspondente em um novo intervalo (min_target a max_target). Retorna um float com o valor interpolado.
    '''
    return np.interp(value, [min_val, max_val], [min_target, max_target])