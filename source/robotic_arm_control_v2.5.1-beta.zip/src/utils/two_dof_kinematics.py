import matplotlib.pyplot as plt
import math

def calculate_end_point(org_point: tuple, L: float, angle_degrees: float) -> tuple:
    '''
        Esta função calcula o ponto final de uma reta, dados seu ponto de origem (cm), comprimento (cm) e ângulo em relação
        ao eixo x em graus. Retorna uma tuple com as coordenadas do ponto final no formato (x,y).
    '''
    # Conversão do ângulo para radianos
    angle_radians = math.radians(angle_degrees)
    # Cálculo das coordenadas do ponto final usando trigonometria
    x_end = org_point[0] + L * math.cos(angle_radians)
    y_end = org_point[1] + L * math.sin(angle_radians)
    return (x_end, y_end)

def relative_position(org_point: tuple, end_point: tuple) -> str:
    '''
        Esta função identifica a posição da haste em relação aos 4 quadrantes do círculo trigonométrico.
        Retorna uma string com a posição identificada.
    '''

    x_relative = None
    y_relative = None
    pos = None

    # Posição relativa em x
    if end_point[0] > org_point[0]:
        x_relative = "right"
    elif end_point[0] < org_point[0]:
        x_relative = "left"
    else:
        x_relative = "equal"

    # Posição relativa em y
    if end_point[1] > org_point[1]:
        y_relative = "up"
    elif end_point[1] < org_point[1]:
        y_relative = "down"
    else:
        y_relative = "equal"

    # Resposta final
    if x_relative == "right" and y_relative == "up":
        pos = "1Q"
    elif x_relative == "left" and y_relative == "up":
        pos = "2Q"
    elif x_relative == "left" and y_relative == "down":
        pos = "3Q"
    elif x_relative == "right" and y_relative == "down":
        pos = "4Q"
    elif x_relative == "equal" and y_relative == "equal":
        pos = "origin"
    elif x_relative == "equal" and y_relative == "up":
        pos = "y_axis_up"
    elif x_relative == "equal" and y_relative == "down":
        pos = "y_axis_down"
    elif y_relative == "equal" and x_relative == "right":
        pos = "x_axis_right"
    elif y_relative == "equal" and x_relative == "left":
        pos = "x_axis_left"
    
    return pos

def calculate_angles(x_coord: float, y_coord: float, L1: float, L2: float) -> list:
    '''
        Essa função utiliza a cinemática inversa para calcular os ângulos das hastes do braço robótico de acordo com um ponto final escolhido
        e os comprimentos de todas as hastes em centímetros. Retorna uma lista com os ângulos calculados.
    '''
    
    # Distância do ponto de origem ao ponto de interesse
    h = math.sqrt(x_coord**2 + y_coord**2)

    # Verificação do alcance do braço
    if (h > (L1 + L2)) or (h < abs(L1 - L2)):
        raise ValueError("Ponto fora do alcance")

    # Ângulo da reta que liga o ponto de origem ao ponto de interesse
    phi = math.atan2(y_coord, x_coord)

    # Ângulo entre h e a primeira haste
    theta = math.acos((h**2 + L1**2 - L2**2) / (2*h*L1))
    
    # Ângulo entre a primeira haste e o eixo x
    alpha_1 = math.degrees(phi - theta)

    # Ângulo entre ambas as hastes
    alpha_2 = math.degrees(math.acos((h**2 - L1**2 - L2**2) / (2*L1*L2)))

    return alpha_1, alpha_2

def calculate_final_servo_angles(org_arm_1: tuple, end_arm_1: tuple, org_arm_2: tuple, end_arm_2: tuple) -> list:
    '''
        Esta função calcula os ângulos finais a serem utilizados pelo programa principal de acordo com os ângulos encontrados pela cinemática
        e com a posição relativa das hastes. Retorna uma lista com os ângulos adequados.
    '''

    # Ângulos finais dos servos
    servo_angle_1 = None
    servo_angle_2 = None

    ### Ângulo formado pelo triângulo (org_arm_1 -> end_arm_1 -. (x1, y1))
    # 1 - Definindo a posição relativa entre os pontos conhecidos
    r_position_1 = relative_position(org_arm_1, end_arm_1)

    # 2 - Calculando a hipotenusa do triângulo
    h1 = math.sqrt((end_arm_1[0] - org_arm_1[0])**2 + (end_arm_1[1] - org_arm_1[1])**2)
    print(f"\nParâmetros - Triângulo 1 -> h1 = {h1:.2f}, y1 = {end_arm_1[1]:.2f}\n")

    # 3 - Calculando o ângulo do primeiro servo
    if r_position_1 == "y_axis_up":
        servo_angle_1 = 90
    elif r_position_1 == "y_axis_down":
        servo_angle_1 = 0
    elif r_position_1 == "x_axis_right":
        servo_angle_1 = 0
    elif r_position_1 == "x_axis_left":
        servo_angle_1 == 180
    elif r_position_1 == "1Q" or r_position_1 == "2Q":
        servo_angle_1 = math.asin(end_arm_1[1]/h1)
        servo_angle_1 = math.degrees(servo_angle_1)
        if r_position_1 == "2Q":
            servo_angle_1 = 90 + (90 - servo_angle_1)
    elif r_position_1 == "3Q":
        servo_angle_1 = 180
    elif r_position_1 == "4Q":
        servo_angle_1 = 0
    else:
        servo_angle_1 = None
    
    ### Ângulo formado pelo triângulo (org_arm_2 -> end_arm_2 -> (x2, y2))
    # 1 - Definindo a posição relativa entre os pontos conhecidos
    r_position_2 = relative_position(org_arm_2, end_arm_2)

    # 2 - Calculando a hipotenusa do triângulo
    h2 = math.sqrt((end_arm_2[0] - org_arm_2[0])**2 + (end_arm_2[1] - org_arm_2[1])**2)
    print(f"\nParâmetros - Triângulo 2 -> h2 = {h2:.2f}, y2 = {end_arm_2[1] - end_arm_1[1]:.2f}\n")

    # 3 - Calculando o ângulo do segundo servo
    if r_position_2 == "y_axis_up":
        servo_angle_2 = 90
    elif r_position_2 == "y_axis_down":
        servo_angle_2 = 0
    elif r_position_2 == "x_axis_right":
        servo_angle_2 = 0
    elif r_position_2 == "x_axis_left":
        servo_angle_2 == 180
    elif r_position_2 == "1Q" or r_position_2 == "2Q":
        servo_angle_2 = math.asin((end_arm_2[1] - end_arm_1[1])/h2)
        servo_angle_2 = math.degrees(servo_angle_2)
        if r_position_2 == "2Q":
            servo_angle_2 = 90 + (90 - servo_angle_2)
    elif r_position_2 == "3Q":
        servo_angle_2 = 180
    elif r_position_2 == "4Q":
        servo_angle_2 = 0
    else:
        servo_angle_2 = None
    
    return servo_angle_1, servo_angle_2

def set_point(x: int, y: int) -> list:
    '''
        Esta função permite a aquisição dos ângulos finais que serão utilizados diretamente no braço robótico de acordo com
        um ponto de interesse de coordendas (x, y). Retorna uma lista com os ângulos adequados.
    '''

    ### Comprimento de cada haste
    L1 = 10.5 # Haste 1
    L2 = 10 # Haste 2

    ### Cálculo dos ângulos de cada haste
    ang_arm_1, ang_arm_2 = calculate_angles(x, y, L1, L2)

    ### Pontos de origem e fim de cada haste
    # Haste 1
    org_arm_1 = (0, 0)
    end_arm_1 = calculate_end_point(org_arm_1, L1, ang_arm_1)
    # Haste 2
    org_arm_2 = end_arm_1
    end_arm_2 = calculate_end_point(org_arm_2, L2, ang_arm_1 + ang_arm_2)

    final_angle_1, final_angle_2 = calculate_final_servo_angles(org_arm_1, end_arm_1, org_arm_2, end_arm_2)
    print(f"arm1 = {final_angle_1}, arm2 = {final_angle_2}")

    return int(final_angle_1), int(final_angle_2)
