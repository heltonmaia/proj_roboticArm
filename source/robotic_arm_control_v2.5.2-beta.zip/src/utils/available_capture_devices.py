import cv2

def capture_devices() -> list:
    '''
        Esta função identifica dispositivos de captura disponíveis e retorna uma lista com os dispositivos encontrados.
    '''
    found_devices = []
    for i in range(10):
        cap = cv2.VideoCapture(i)
        if cap.read()[0]:
            found_devices.append(i)
        cap.release()
    return found_devices
